import "../styles/globals.css";
import { useEffect } from "react";
import Layout from "../components/Layout";

export default function App({ Component, pageProps }) {
  useEffect(() => {
    // Initialize ScrollReveal client-side only
    if (typeof window === "undefined") return;
    import("scrollreveal").then((mod) => {
      const ScrollReveal = mod.default;
      ScrollReveal().reveal(".sr", {
        origin: "bottom",
        distance: "18px",
        duration: 600,
        delay: 80,
        interval: 80,
        easing: "cubic-bezier(.2,.8,.2,1)",
        reset: false,
        mobile: true
      });
    });
  }, []);

  return (
    <Layout>
      <Component {...pageProps} />
    </Layout>
  );
}