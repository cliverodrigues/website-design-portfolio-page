import dynamic from "next/dynamic";
import { motion } from "framer-motion";
import Hero from "../components/sections/Hero";
import Services from "../components/sections/Services";
import Work from "../components/sections/Work";
import Process from "../components/sections/Process";
import Why from "../components/sections/Why";
import Contact from "../components/sections/Contact";

/* Lottie (lazy) - we will dynamically load the Lottie component where needed */
export default function Home() {
  return (
    <div className="space-y-16 py-6">
      <section className="sr">
        <Hero />
      </section>

      <section id="services" className="sr">
        <Services />
      </section>

      <section id="work" className="sr">
        <Work />
      </section>

      <section id="process" className="sr">
        <Process />
      </section>

      <section id="why" className="sr">
        <Why />
      </section>

      <section id="contact" className="sr">
        <Contact />
      </section>
    </div>
  );
}