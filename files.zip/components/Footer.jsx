export default function Footer() {
  return (
    <footer className="py-10 text-center text-sm text-muted">
      © {new Date().getFullYear()} Clive Rodrigues — Design. All rights reserved.
    </footer>
  );
}