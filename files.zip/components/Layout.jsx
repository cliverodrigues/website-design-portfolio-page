import Head from "next/head";
import Header from "./Header";
import Footer from "./Footer";

export default function Layout({ children }) {
  return (
    <>
      <Head>
        <meta name="viewport" content="width=device-width,initial-scale=1" />
        <title>Get a website that sells — DTC & e‑commerce design</title>
        <meta name="description" content="Solo designer building fast, conversion-focused e-commerce and brand websites for DTC brands." />
      </Head>

      <div className="container">
        <Header />
        <main>{children}</main>
        <Footer />
      </div>
    </>
  );
}