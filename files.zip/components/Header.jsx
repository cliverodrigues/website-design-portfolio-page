import Link from "next/link";

export default function Header() {
  return (
    <header className="flex items-center justify-between py-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-md bg-gradient-to-b from-accent to-[#057985] text-white flex items-center justify-center font-bold">CR</div>
        <div>
          <div className="font-semibold">Clive Rodrigues — Design</div>
          <div className="text-sm text-muted">E‑commerce & brand websites</div>
        </div>
      </div>

      <nav className="text-sm text-muted hidden md:flex gap-6">
        <a href="#services">Services</a>
        <a href="#work">Selected work</a>
        <a href="#process">Process</a>
        <a href="#contact">Contact</a>
      </nav>
    </header>
  );
}