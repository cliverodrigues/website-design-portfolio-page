export default function Work() {
  const projects = [
    { name: "Riviera", title: "Riviera Apparel — DTC clothing concept (sample)", meta: "Problem: High browse-to-cart friction. Solution: improved product hierarchy, size guidance, simplified variants." },
    { name: "Maison", title: "Maison & Co. — Home goods concept (sample)", meta: "Problem: Low conversion on hero launches. Solution: focused hero, social proof, and bundles." },
    { name: "Bloom", title: "Bloom & Curate — Beauty brand demo (sample)", meta: "Problem: Confusing options slowed checkout. Solution: guided selector and loyalty strip." },
    { name: "QuickCart", title: "QuickCart — Fast checkout concept (sample)", meta: "Problem: Cart abandonment. Solution: minimalist one-step checkout with trust markers." }
  ];

  return (
    <div>
      <div className="flex items-baseline justify-between">
        <h2 className="text-lg font-bold">Selected work — concepts & demos</h2>
        <div className="text-sm text-muted">Real design concepts demonstrating conversion-driven solutions</div>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {projects.map((p) => (
          <div key={p.name} className="flex gap-4 items-start bg-card p-4 rounded-xl shadow-sm">
            <div className="w-28 h-16 rounded-md bg-[linear-gradient(180deg,#0b728520,#0b728510)] flex items-center justify-center text-accent font-bold">{p.name}</div>
            <div>
              <h4 className="font-semibold">{p.title}</h4>
              <div className="text-sm text-muted mt-2">{p.meta}</div>
            </div>
          </div>
        ))}
      </div>

      <p className="mt-4 text-sm text-muted">Note: these are concept projects and demos meant to show approach and outcomes. I adapt the same patterns to your brand and product set.</p>
    </div>
  );
}