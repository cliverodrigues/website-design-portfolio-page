export default function Process() {
  const steps = [
    { n: "01", title: "Strategy & brief", desc: "Define goals, KPIs, product priorities and launch scope in a short actionable brief." },
    { n: "02", title: "Design", desc: "Wireframes and high-fidelity pages focused on product presentation and conversion paths." },
    { n: "03", title: "Build", desc: "Fast front-end implementation with staging review and merchant setup." },
    { n: "04", title: "Launch & iterate", desc: "Validate metrics and iterate in short cycles based on user data." }
  ];

  return (
    <div>
      <div className="flex items-baseline justify-between">
        <h2 className="text-lg font-bold">Process — clear steps, predictable timelines</h2>
        <div className="text-sm text-muted">Designed for clarity and quick decision-making</div>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-4">
        {steps.map(s => (
          <div key={s.n} className="bg-card p-4 rounded-xl shadow-sm">
            <div className="text-accent font-bold">{s.n}</div>
            <h5 className="mt-2 font-semibold">{s.title}</h5>
            <p className="mt-2 text-sm text-muted">{s.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}