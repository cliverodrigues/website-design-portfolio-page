import { motion } from "framer-motion";

export default function Hero() {
  return (
    <div className="grid md:grid-cols-2 gap-6 items-center py-6">
      <div>
        <span className="inline-block bg-[rgba(11,114,133,0.08)] text-accent px-3 py-1 rounded-full text-sm font-semibold">Focused on conversions</span>

        <motion.h1
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mt-4 text-2xl md:text-4xl font-bold leading-tight"
        >
          Get a website that sells — e‑commerce & brand sites for growing DTC businesses
        </motion.h1>

        <p className="mt-4 text-muted max-w-prose">
          I design and build fast, conversion-first stores and brand sites that reduce checkout friction, lift average order value, and present products the way customers expect to buy.
        </p>

        <div className="mt-6 flex gap-3">
          <a href="mailto:hello@yourdomain.com?subject=Website%20Inquiry" className="inline-flex items-center gap-3 bg-accent text-white px-4 py-2 rounded-lg font-semibold shadow-md">Get a website that sells</a>
          <a href="#work" className="inline-flex items-center gap-3 border border-[rgba(15,23,32,0.06)] px-4 py-2 rounded-lg">See selected work</a>
        </div>

        <p className="mt-4 text-sm text-muted">Typical clients: clothing, lifestyle, beauty, and consumer brands. Projects: full e‑commerce builds, product launches, and redesigns focused on conversion and speed.</p>
      </div>

      <aside className="bg-card rounded-xl p-6 shadow-md">
        <div className="font-semibold">Quick project snapshot</div>
        <p className="mt-2 text-muted">Launch-ready store with optimized product pages, simplified checkout, and a brand-led homepage — typically delivered in 4–8 weeks depending on scope.</p>

        <div className="mt-4 flex gap-3">
          <a href="mailto:hello@yourdomain.com?subject=Schedule%20consult" className="bg-accent text-white px-3 py-2 rounded-md font-semibold">Book a consult</a>
          <a href="https://wa.me/15551234567" className="px-3 py-2 rounded-md border">Message on WhatsApp</a>
        </div>
      </aside>
    </div>
  );
}