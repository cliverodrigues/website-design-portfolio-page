export default function Why() {
  return (
    <div className="md:flex md:gap-6">
      <div className="flex-1">
        <div className="border-l-4 border-accent bg-[rgba(11,114,133,0.03)] p-4 rounded-lg">
          <strong>Direct line to the person doing the work.</strong>
          <p className="mt-2 text-sm text-muted">Consistent decisions, faster turnarounds, and one point of accountability for both design and delivery.</p>
        </div>
      </div>

      <div className="flex-1 mt-4 md:mt-0">
        <ul className="space-y-4">
          <li className="flex gap-3 items-start">
            <div className="w-3 h-3 rounded-sm bg-accent mt-2" />
            <div>
              <strong>Fast turnaround</strong>
              <div className="text-sm text-muted">Streamlined process reduces back-and-forth and speeds time to market.</div>
            </div>
          </li>

          <li className="flex gap-3 items-start">
            <div className="w-3 h-3 rounded-sm bg-accent mt-2" />
            <div>
              <strong>No agency overhead</strong>
              <div className="text-sm text-muted">You pay for design and build, not excess meetings or account layers.</div>
            </div>
          </li>

          <li className="flex gap-3 items-start">
            <div className="w-3 h-3 rounded-sm bg-accent mt-2" />
            <div>
              <strong>Metrics-driven</strong>
              <div className="text-sm text-muted">Design decisions are tied to conversion, AOV, and cart completion metrics.</div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  );
}