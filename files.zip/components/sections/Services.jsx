export default function Services() {
  const list = [
    { title: "Full E‑commerce Stores", body: "Launch a fast, conversion-first store with product pages, collections, and checkout optimizations. I handle design and front-end build so you can sell from day one." },
    { title: "Conversion Optimization", body: "Redesign product pages and checkout flows to reduce drop-off with clearer hierarchy and persuasive microcopy." },
    { title: "Brand & Visual Design", body: "Brand-led homepages and product presentation that build trust and highlight product desirability." },
    { title: "Performance & SEO", body: "Fast-loading templates, semantic markup, and on-page SEO to improve discoverability and reduce bounce." },
    { title: "UX for Product Discovery", body: "Filters, cross-sell sections and navigation that shorten the path to purchase." },
    { title: "Ongoing Support", body: "Post-launch support, A/B test recommendations, and iterative improvements focused on revenue metrics." }
  ];

  return (
    <div>
      <div className="flex items-baseline justify-between">
        <h2 className="text-lg font-bold">Services — outcomes I deliver</h2>
        <div className="text-sm text-muted">Clear deliverables, no agency overhead</div>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        {list.map((s) => (
          <article key={s.title} className="bg-card p-4 rounded-xl shadow-sm">
            <h3 className="font-semibold">{s.title}</h3>
            <p className="mt-2 text-sm text-muted">{s.body}</p>
          </article>
        ))}
      </div>
    </div>
  );
}