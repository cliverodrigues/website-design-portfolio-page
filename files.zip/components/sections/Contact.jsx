export default function Contact() {
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <h2 className="text-lg font-bold">Contact — start with a short consult</h2>
        <div className="text-sm text-muted">Quick 20-minute call to scope priorities and timelines</div>
      </div>

      <div className="mt-6 bg-card p-4 rounded-xl shadow-sm flex flex-col md:flex-row gap-4 items-center">
        <div>
          <div className="font-semibold">Email</div>
          <div className="text-sm text-muted mt-1"><a href="mailto:hello@yourdomain.com">hello@yourdomain.com</a></div>
        </div>

        <div>
          <div className="font-semibold">WhatsApp</div>
          <div className="text-sm text-muted mt-1"><a href="https://wa.me/15551234567">+1 (555) 123‑4567</a></div>
        </div>

        <div className="ml-auto text-right">
          <div className="font-semibold">Ready to get started?</div>
          <div className="text-sm text-muted">Reply with a short note about product, traffic, and timeline — I’ll respond within one business day.</div>
        </div>
      </div>
    </div>
  );
}